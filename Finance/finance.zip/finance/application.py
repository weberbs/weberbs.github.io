import os
import time

from cs50 import SQL
from flask import Flask, flash, jsonify, redirect, render_template, request, session
from flask_session import Session
from tempfile import mkdtemp
from werkzeug.exceptions import default_exceptions, HTTPException, InternalServerError
from werkzeug.security import check_password_hash, generate_password_hash

from helpers import apology, login_required, lookup, usd

# Configure application
app = Flask(__name__)

# Ensure templates are auto-reloaded
app.config["TEMPLATES_AUTO_RELOAD"] = True

# Ensure responses aren't cached
@app.after_request
def after_request(response):
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Expires"] = 0
    response.headers["Pragma"] = "no-cache"
    return response

# Custom filter
app.jinja_env.filters["usd"] = usd

# Configure session to use filesystem (instead of signed cookies)
app.config["SESSION_FILE_DIR"] = mkdtemp()
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

# Configure CS50 Library to use SQLite database
db = SQL("sqlite:///finance.db")

# Make sure API key is set
if not os.environ.get("API_KEY"):
    raise RuntimeError("API_KEY not set")


@app.route("/")
@login_required
def index():
    """Show portfolio of stocks"""
    row = db.execute("SELECT * FROM users WHERE id = ?", session['user_id'])
    cash = usd(row[0]["cash"])
    holdings = db.execute("SELECT * FROM holdings WHERE user_id = ? ORDER BY 'ticker'", session['user_id'])
    accountTotal = row[0]["cash"]

    asset = []
    value = []
    owned = []
    total = []

    for i in range(len(holdings)):
        asset.append(holdings[i]["ticker"])
        value.append(lookup(holdings[i]["ticker"])['price'])
        owned.append(holdings[i]["numShares"])
        total.append(value[i] * owned[i])
        accountTotal = accountTotal + total[i]
        value[i] = usd(value[i])
        total[i] = usd(total[i])

    accountTotal = usd(accountTotal)
    asset_value_owned_total = zip(asset,value,owned,total)
    return render_template("index.html", cash=cash, asset_value_owned_total=asset_value_owned_total, accountTotal = accountTotal)


@app.route("/buy", methods=["GET", "POST"])
@login_required
def buy():
    """Buy shares of stock"""
    #get current cash holdings
    rows = db.execute("SELECT * FROM users WHERE id = ?", session['user_id'])
    money = (rows[0]["cash"])
    cash = usd(rows[0]["cash"])
    if request.method == "GET":
        return render_template("buy.html", cash=cash)
    else:
        if not request.form.get("ticker"):
            flash("please enter stock ticker")
            return redirect ("/buy")
        shares = int(request.form.get("shares"))
        if shares < 1:
            flash("please enter at least 1 share")
            return redirect ("/buy")

        else:
            ticker = request.form.get("ticker")
            stats = lookup(ticker)
            if stats == None:
                flash( "Ticker not found in IEX, try another")
                return redirect ("/buy")
            else:
                cost = shares * float(stats['price'])
                if cost > money:
                    flash("insufficient cash")
                    return redirect ("/buy")
                else:
                    #get current holdings if any
                    money = money - cost
                    db.execute("UPDATE users SET cash = (?) WHERE id = (?)", money, session['user_id'])
                    row = db.execute("SELECT * FROM holdings WHERE ticker = (?) AND user_id = (?)", ticker, session['user_id'])
                    if len(row) == 0:
                        db.execute("INSERT INTO holdings (ticker, user_id, numShares) VALUES (?,?,?)", ticker, session['user_id'], shares)
                        db.execute("INSERT INTO transactions (type, user_id, numShares, ticker) VALUES (?,?,?,?)","BUY",session['user_id'], shares, ticker)
                        flash("purchase succesful")
                        return redirect("/")
                    else:
                        holdings = row[0]['numShares']
                        shares = shares + holdings
                        db.execute("UPDATE holdings SET ticker = (?), user_id = (?), numShares = (?)", ticker, session['user_id'], shares)
                        db.execute("INSERT INTO transactions (type, user_id, numShares, ticker) VALUES (?,?,?,?)","BUY",session['user_id'], shares, ticker)
                        flash("purchase succesful")
                        return redirect("/")



@app.route("/history")
@login_required
def history():
    """Show history of transactions"""
    rows = db.execute("SELECT * FROM transactions WHERE user_id = (?) ORDER BY time", session['user_id'])
    return render_template("history.html", rows=rows)


@app.route("/login", methods=["GET", "POST"])
def login():
    """Log user in"""

    # Forget any user_id
    session.clear()

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":

        # Ensure username was submitted
        if not request.form.get("username"):
            return apology("must provide username", 403)

        # Ensure password was submitted
        elif not request.form.get("password"):
            return apology("must provide password", 403)

        # Query database for username
        rows = db.execute("SELECT * FROM users WHERE username = :username",
                          username=request.form.get("username"))

        # Ensure username exists and password is correct
        if len(rows) != 1 or not check_password_hash(rows[0]["hash"], request.form.get("password")):
            return apology("invalid username and/or password", 403)

        # Remember which user has logged in
        session["user_id"] = rows[0]["id"]

        # Redirect user to home page
        return redirect("/")

    # User reached route via GET (as by clicking a link or via redirect)
    else:
        return render_template("login.html")


@app.route("/logout")
def logout():
    """Log user out"""

    # Forget any user_id
    session.clear()

    # Redirect user to login form
    return redirect("/")


@app.route("/quote", methods=["GET", "POST"])
@login_required
def quote():
    """Get stock quote."""
    if request.method == "GET":
        return render_template("quote.html")
    else:

        if not request.form.get("ticker"):
            flash("please enter stock ticker")
            return redirect ("/quote")

        else:
            ticker = request.form.get("ticker")
            stats = lookup(ticker)
            if stats == None:
                flash( "Ticker not found in IEX, try another")
                return redirect ("/quote")
            else:
                return render_template("quoted.html", stats=stats)


    # return apology("TODO")


@app.route("/register", methods=["GET", "POST"])
def register():
    """Register user"""
    if request.method == "GET":
        return render_template("register.html")
    if request.method == "POST":
        # Ensure username was submitted
        if not request.form.get("username"):
            return apology("must provide username", 403)
        # Ensure password was submitted
        if not request.form.get("password"):
            return apology("must provide password", 403)
        #check for valid username
        username = request.form.get("username")
        rows = db.execute("SELECT * FROM users WHERE username = (?)", username)
        if len(rows) != 0:
            flash("Username is already taken")
            return redirect("/register")
        #check password is confirmed
        if request.form.get("password")!=request.form.get("passwordConfirm"):
            flash("Passwords do not match")
            return redirect("/register")
        else:
            #add username and password to table
            passwordHash = generate_password_hash(request.form.get("password"))
            db.execute("INSERT INTO users (username, hash) VALUES (?,?)",username,passwordHash)
            #redirect to login page with success alert
            flash("Successfully registered!")
            time.sleep(1)
        return redirect("/login")

@app.route("/sell", methods=["GET", "POST"])
@login_required
def sell():
    """Sell shares of stock"""
    row = db.execute("SELECT * FROM users WHERE id = ?", session['user_id'])
    holdings = db.execute("SELECT * FROM holdings WHERE user_id = ? ORDER BY 'ticker'", session['user_id'])
    accountTotal = row[0]["cash"]
    cash = usd(row[0]["cash"])

    asset = []
    value = []
    owned = []
    total = []

    for i in range(len(holdings)):
        asset.append(holdings[i]["ticker"])
        value.append(lookup(holdings[i]["ticker"])['price'])
        owned.append(holdings[i]["numShares"])
        total.append(value[i] * owned[i])
        accountTotal = accountTotal + total[i]
        value[i] = usd(value[i])
        total[i] = usd(total[i])

    if request.method == 'GET':
        accountTotal = usd(accountTotal)
        asset_value_owned_total = zip(asset,value,owned,total)
        return render_template("sell.html",cash=cash, asset_value_owned_total=asset_value_owned_total, accountTotal=accountTotal, asset=asset)
    else:
        ticker = request.form.get("sell")
        shares = int(request.form.get("shares"))
        row = db.execute("SELECT * FROM holdings WHERE user_id = ? AND ticker = ?", session['user_id'], ticker)
        currHoldings = row[0]['numShares']
        amount = shares * (lookup(holdings[i]["ticker"])['price'])
        if (shares < 0) or (shares > currHoldings):
            flash("invalid number of shares")
            redirect("/sell")
        else:
            db.execute("INSERT INTO transactions (type, user_id, numShares, ticker) VALUES (?,?,?,?)","SELL",session['user_id'], shares, ticker)
            newHoldings = row[0]['numShares'] - shares
            if newHoldings == 0:
                db.execute("DELETE FROM holdings WHERE user_id = ? AND ticker = ?", session['user_id'], ticker)
                flash ("transaction succesful")
            else:
                db.execute("UPDATE holdings SET numShares = ? WHERE user_id = ? AND ticker = ?", newHoldings, session['user_id'], ticker)
                flash ("transaction succesful")
            return redirect("/sell")


def errorhandler(e):
    """Handle error"""
    if not isinstance(e, HTTPException):
        e = InternalServerError()
    return apology(e.name, e.code)


# Listen for errors
for code in default_exceptions:
    app.errorhandler(code)(errorhandler)
