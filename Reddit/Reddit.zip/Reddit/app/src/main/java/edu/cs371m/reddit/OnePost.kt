package edu.cs371m.reddit

import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuInflater
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.TextView
import androidx.appcompat.app.ActionBar
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.fragment.app.FragmentTransaction
import androidx.fragment.app.activityViewModels
import edu.cs371m.reddit.glide.Glide
import edu.cs371m.reddit.ui.HomeFragment
import edu.cs371m.reddit.ui.MainViewModel
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.one_post.*


class OnePost : AppCompatActivity() {
    lateinit var title : String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.one_post)
        val activityThatCalled = intent
        val callingBundle = activityThatCalled.extras

        title = callingBundle.getString("title")
        titleTV.text = title
        Glide.glideFetch(callingBundle.getString("image"),callingBundle.getString("thumbnail"), image)
        selfText.text = callingBundle.getString("selfText")

        toolbarTitleTV.text = title
        back.setOnClickListener {
            finish()
        }
    }


}