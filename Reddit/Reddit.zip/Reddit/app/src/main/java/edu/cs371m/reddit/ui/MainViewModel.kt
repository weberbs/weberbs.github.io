package edu.cs371m.reddit.ui


import android.content.Context
import android.graphics.Color
import android.text.Spannable
import android.text.SpannableString
import android.text.style.ForegroundColorSpan
import android.util.Log
import androidx.core.text.clearSpans
import androidx.core.text.toSpannable
import androidx.lifecycle.*
import edu.cs371m.reddit.api.RedditApi
import edu.cs371m.reddit.api.RedditPost
import edu.cs371m.reddit.api.RedditPostRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

// XXX Much to write
class MainViewModel : ViewModel() {
    private var title = MutableLiveData<String>()
    private var searchTerm = MutableLiveData<String>()
    private var subreddit = MutableLiveData<String>().apply {
        value = "aww"
    }
    private var repository = RedditPostRepository(RedditApi.create())
    private val netPosts = MutableLiveData<List<RedditPost>>()
    private val subreddits = MutableLiveData<List<RedditPost>>()
    private val favorites = MutableLiveData<List<RedditPost>>().apply {
        value = mutableListOf()
    }
    private var searchFavs = MediatorLiveData<List<RedditPost>>().apply {
        addSource(searchTerm) {value = filterFavs()}
        value = favorites.value
    }

    private var searchSubreddits = MediatorLiveData<List<RedditPost>>().apply {
        addSource(searchTerm) {value =filterSubs()}
        value = subreddits.value
    }

    private var searchPosts = MediatorLiveData<List<RedditPost>>().apply {
        addSource(searchTerm) {value = filterList()}
        value = netPosts.value
    }
    // XXX Write netPosts/searchPosts

    // NB: I don't fully understand why I need to put these addSource(searchTerm)
    // lines in init, while I can add it to the initial value for searchPosts
    // If these are initialized in the apply block above, I get
    // a runtime error about ObserveForever on a null reference.
    // Maybe something about how ViewModel is initialized in the fragment, either a
    // bug or behavior/initialization order I don't understand
    init {
        netRefresh()
    }
    fun setSearchTerm(s: String) {
        searchTerm.value = s
    }

    fun netRefresh() {
        Log.d("here", "net refresh")
        viewModelScope.launch(
            context = viewModelScope.coroutineContext
                    + Dispatchers.IO) {
                netPosts.postValue(repository.getPosts(subreddit.value!!))
                subreddits.postValue(repository.getSubreddits())
            }
    }
    internal fun observeFav(): LiveData<List<RedditPost>> {
        return favorites
    }
    fun addFav(postRec: RedditPost) {
        val localList = favorites.value?.toMutableList()
        localList?.let {
            it.add(postRec)
            favorites.postValue(it)
        }
    }
    fun isFav(newPost: RedditPost): Boolean {
        if (favorites.value == null) {
            return false
        }
        for (oldPost in favorites.value!!) {
            if (oldPost.key == newPost.key) {
                return true
            }
        }
        return false
    }
    fun removeFav(postRec: RedditPost) {
        val localList = favorites.value?.toMutableList()
        localList?.let {
            it.remove(postRec)
            favorites.value = it
        }
    }
    fun getListAt(position: Int): RedditPost? {
        val localList = netPosts.value?.toList()
        localList?.let {
            if(position >= it.size ) return null
            return it[position]
        }
        return null
    }

    fun observeSubreddits() : LiveData<List<RedditPost>> {
        return subreddits
    }
    fun setSubreddit(sub : String) {
        subreddit.value = sub
    }

    fun observePosts(): LiveData<List<RedditPost>> {
        return netPosts
    }

    fun observeSearchPosts(): LiveData<List<RedditPost>> {
        return searchPosts
    }

    fun observeSearchFavs(): LiveData<List<RedditPost>> {
        return searchFavs
    }


    fun observeSearchSubs(): LiveData<List<RedditPost>> {
        return searchSubreddits
    }

    // NB: This only highlights the first match
    private fun setSpan(fulltext: SpannableString, subtext: String): Boolean {
        if( subtext.isEmpty() ) return true
        val i = fulltext.indexOf(subtext, ignoreCase = true)
        if( i == -1 ) return false
        fulltext.setSpan(
            ForegroundColorSpan(Color.BLUE), i, i + subtext.length,
            Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
        )
        return true
    }
    private fun removeAllCurrentSpans(list : MutableLiveData<List<RedditPost>> ){
        list.value?.forEach {
            it.title.clearSpans()
            it.selfText?.clearSpans()
        }
    }

    private fun filterList(): List<RedditPost> {
        // If you can't figure out why this is here, comment it out and
        // see what happens
        removeAllCurrentSpans(netPosts)
        // We know value is not null
        val searchTermValue = searchTerm.value!!
        return netPosts.value!!.filter {
            var titleFound = false
            var selfTextFound = false
            titleFound = setSpan(it.title, searchTermValue)
            if (it.selfText != null) {
                selfTextFound = setSpan(it.selfText, searchTermValue)
            }
            titleFound || selfTextFound
        }
    }
    private fun filterFavs(): List<RedditPost> {
        // If you can't figure out why this is here, comment it out and
        // see what happens
        removeAllCurrentSpans(favorites)
        // We know value is not null
        val searchTermValue = searchTerm.value!!
        return favorites.value!!.filter {
            var titleFound = false
            var selfTextFound = false
            titleFound = setSpan(it.title, searchTermValue)
            if (it.selfText != null) {
                selfTextFound = setSpan(it.selfText, searchTermValue)
            }
            titleFound || selfTextFound
        }
    }

    private fun filterSubs(): List<RedditPost> {
        // If you can't figure out why this is here, comment it out and
        // see what happens
        removeAllCurrentSpans(subreddits)
        // We know value is not null
        val searchTermValue = searchTerm.value!!
        return subreddits.value!!.filter {
            var displayNameFound = false
            var publicDescriptionFound = false
            if (it.displayName != null) {
                displayNameFound = setSpan(it.displayName, searchTermValue)
            }
            if (it.publicDescription != null) {
                publicDescriptionFound = setSpan(it.publicDescription, searchTermValue)
            }
            displayNameFound || publicDescriptionFound
        }
    }



    fun observeTitle(): LiveData<String> {
        return title
    }
    fun setTitle(newTitle: String) {
        title.value = newTitle
    }
    // NB: This function is a bit of a bummer because it leaks some view information
    // into our view model.  However, the problem of how to update the action bar title
    // when the user goes to subreddit list/favorites and then returns is vexing.
    // Believe me, this solution is better then what I had previously
    fun setTitleToSubreddit() {
        title.value = "r/${subreddit.value}"
    }

}