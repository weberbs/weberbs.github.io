package edu.cs371m.reddit.ui.subreddits

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import androidx.activity.addCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import edu.cs371m.reddit.MainActivity
import edu.cs371m.reddit.R
import edu.cs371m.reddit.ui.MainViewModel
import edu.cs371m.reddit.ui.PostRowAdapter


class Subreddits : Fragment() {
    private val viewModel: MainViewModel by activityViewModels()
    internal lateinit var adapter : SubredditListAdapter
    internal lateinit var oldtitle : String
    internal lateinit var editText: EditText
    internal lateinit var myTextWatcher: TextWatcher


    // XXX initialize viewModel

    companion object {
        fun newInstance(): Subreddits {
            return Subreddits()
        }
    }
    private fun initAdapter(root: View) {
        val rv = root.findViewById<RecyclerView>(R.id.recyclerView)
        rv.layoutManager = LinearLayoutManager(root.context)
        adapter = SubredditListAdapter(viewModel)
        rv.adapter = adapter
        adapter.notifyDataSetChanged()
        val swipe = root.findViewById<SwipeRefreshLayout>(R.id.swipeRefreshLayout)
        swipe.isEnabled = false
    }

    private fun getTextWatcher() : TextWatcher {
        return object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {}
            override fun beforeTextChanged(s: CharSequence?,start: Int,count: Int,after: Int) {}
            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                if(s.isEmpty()) (activity as MainActivity).hideKeyboard()
                viewModel.setSearchTerm(s.toString())
                viewModel.observeSearchSubs().observe(
                    viewLifecycleOwner,
                    Observer {
                        adapter.subreddits = it
                        adapter.notifyDataSetChanged()
                    }
                )

            }
        }
    }


    // If you want to get control when the user hits the system back button, get
    // a reference to the activity and call .onBackPressedDispatcher.addCallback(this)
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        (activity as AppCompatActivity).supportActionBar?.title = "RV reddit post list"
        Log.d("here", "on create view home Fragment")
        oldtitle = viewModel.observeTitle().value ?: "r/aww"
        viewModel.setTitle("Pick")
        setHasOptionsMenu(true)
        val view =  inflater.inflate(R.layout.fragment_rv, container, false)
        initAdapter(view)
        myTextWatcher = getTextWatcher()
        editText = requireActivity().findViewById(R.id.actionSearch)
        editText.addTextChangedListener(myTextWatcher)
        requireActivity().onBackPressedDispatcher.addCallback(this){
            viewModel.setTitle(oldtitle)
            parentFragmentManager.popBackStack()
        }
        return view
    }

    override fun onDestroyView() {
        super.onDestroyView()
        editText.removeTextChangedListener(myTextWatcher)
    }

}