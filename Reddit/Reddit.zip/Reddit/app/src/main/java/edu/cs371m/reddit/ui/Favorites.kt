package edu.cs371m.reddit.ui

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import androidx.activity.addCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import edu.cs371m.reddit.MainActivity
import edu.cs371m.reddit.R
import edu.cs371m.reddit.ui.subreddits.SubredditListAdapter
import kotlinx.android.synthetic.main.action_bar.*

class Favorites: Fragment() {
    private val viewModel: MainViewModel by activityViewModels()
    internal lateinit var adapter : PostRowAdapter
    internal lateinit var oldtitle : String
    internal lateinit var editText: EditText
    internal lateinit var myTextWatcher: TextWatcher

    companion object {
        fun newInstance(): Favorites {
            return Favorites()
        }
    }
    private fun initAdapter(root: View) {
        val rv = root.findViewById<RecyclerView>(R.id.recyclerView)
        rv.layoutManager = LinearLayoutManager(root.context)
        adapter = PostRowAdapter(viewModel)
        rv.adapter = adapter
        viewModel.observeFav().observe(
            viewLifecycleOwner,
            Observer {
                adapter.submitList(it)
                adapter.notifyDataSetChanged()
            }
        )
        val swipe = root.findViewById<SwipeRefreshLayout>(R.id.swipeRefreshLayout)
        swipe.isEnabled = false

    }
    private fun getTextWatcher() : TextWatcher {
        return object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {}
            override fun beforeTextChanged(s: CharSequence?,start: Int,count: Int,after: Int) {}
            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                if(s.isEmpty()) (activity as MainActivity).hideKeyboard()
                viewModel.setSearchTerm(s.toString())
                viewModel.observeSearchFavs().observe(
                    viewLifecycleOwner,
                    Observer {
                        adapter.submitList(it)
                        adapter.notifyDataSetChanged()
                    }
                )

            }
        }
    }


    // If you want to get control when the user hits the system back button, get
    // a reference to the activity and call .onBackPressedDispatcher.addCallback(this)
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        (activity as AppCompatActivity).supportActionBar?.title = "RV favorite list"
        oldtitle = viewModel.observeTitle().value ?: "r/aww"
        viewModel.setTitle("Favorites")
        setHasOptionsMenu(true)
        val view =  inflater.inflate(R.layout.fragment_rv, container, false)
        initAdapter(view)
        requireActivity().onBackPressedDispatcher.addCallback(this){
            viewModel.setTitle(oldtitle)
            parentFragmentManager.popBackStack()
        }
        myTextWatcher = getTextWatcher()
        editText = requireActivity().findViewById(R.id.actionSearch)
        editText.addTextChangedListener(myTextWatcher)
        return view
    }

    override fun onDestroyView() {
        super.onDestroyView()
        editText.removeTextChangedListener(myTextWatcher)
    }

}