package edu.cs371m.reddit.ui

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentTransaction
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import edu.cs371m.reddit.MainActivity
import edu.cs371m.reddit.R
import edu.cs371m.reddit.ui.subreddits.Subreddits
import kotlinx.android.synthetic.main.action_bar.*
import kotlinx.android.synthetic.main.fragment_rv.*


// XXX Write most of this file
class HomeFragment: Fragment() {
    private lateinit var swipe: SwipeRefreshLayout
    private val favoritesFragTag = "favoritesFragTag"
    private val subredditsFragTag = "subredditsFragTag"
    private val viewModel: MainViewModel by activityViewModels()
    internal lateinit var adapter : PostRowAdapter

    companion object {
        fun newInstance(): HomeFragment {
            return HomeFragment()
        }
    }
    private fun initTitleObservers() {
        viewModel.setTitle("r/aww")
        viewModel.observeTitle().observe(
            viewLifecycleOwner,
            Observer {
                requireActivity().actionTitle.text = it
            }
        )
    }
    private fun initActionBarListeners() {
        requireActivity().actionTitle.setOnClickListener {
            val frag = viewModel.observeTitle().value
            if (frag == "Favorites" || frag == "Pick") {

            } else {
                actionSubreddit()
            }
        }
        requireActivity().actionFavorite.setOnClickListener {
            val frag = viewModel.observeTitle().value

            if (frag == "Favorites" || frag == "Pick") {
            } else {
                actionFavorite()
            }
        }

    }

    // XXX check out addTextChangedListener
    private fun actionSearch() {
        activity
            ?.findViewById<EditText>(R.id.actionSearch)
            ?.addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) {}
                override fun beforeTextChanged(s: CharSequence?,start: Int,count: Int,after: Int) {}
                override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                    if(s.isEmpty()) (activity as MainActivity).hideKeyboard()
                    viewModel.setSearchTerm(s.toString())
                    viewModel.observeSearchPosts().observe(
                        viewLifecycleOwner,
                        Observer {
                            adapter.submitList(it)
                            adapter.notifyDataSetChanged()
                        }
                    )

                }
            })
    }

    private fun actionSubreddit() {
        parentFragmentManager
            .beginTransaction()
            .add(R.id.main_frame, Subreddits.newInstance())
            .addToBackStack(null)
            .commit()
    }

    private fun actionFavorite() {
        parentFragmentManager
            .beginTransaction()
            .add(R.id.main_frame, Favorites.newInstance())
            .addToBackStack(null)
            .commit()
    }

    // Set up the adapter
    private fun initAdapter(root: View) {
        val rv = root.findViewById<RecyclerView>(R.id.recyclerView)
        rv.layoutManager = LinearLayoutManager(root.context)
        adapter = PostRowAdapter(viewModel)
        rv.adapter = adapter
        viewModel.observePosts().observe(
            viewLifecycleOwner,
            Observer {
                adapter.submitList(it)
            }
        )


    }

    private fun initSwipeLayout(root: View) {
        val swipe = root.findViewById<SwipeRefreshLayout>(R.id.swipeRefreshLayout)
        swipe.setOnRefreshListener {
            viewModel.netRefresh()
            swipe.isRefreshing = false
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        (activity as AppCompatActivity).supportActionBar?.title = "RV reddit post list"
        setHasOptionsMenu(true)
        val view =  inflater.inflate(R.layout.fragment_rv, container, false)
        initAdapter(view)
        initTitleObservers()
        initActionBarListeners()
        initSwipeLayout(view)
        actionSearch()
        return view
    }

    override fun onStart() {
        Log.d("XXX", "homefrag resume")
        initActionBarListeners()
        super.onStart()
    }

}