package edu.cs371m.reddit.ui.subreddits

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.fragment.app.FragmentActivity
import androidx.recyclerview.widget.RecyclerView
import edu.cs371m.reddit.R
import edu.cs371m.reddit.api.RedditPost
import edu.cs371m.reddit.glide.Glide
import edu.cs371m.reddit.ui.MainViewModel

// NB: Could probably unify with PostRowAdapter if we had two
// different VH and override getItemViewType
// https://medium.com/@droidbyme/android-recyclerview-with-multiple-view-type-multiple-view-holder-af798458763b
class SubredditListAdapter(private val viewModel: MainViewModel)
    : RecyclerView.Adapter<SubredditListAdapter.VH>() {

    var subreddits = viewModel.observeSubreddits().value

    // ViewHolder pattern minimizes calls to findViewById
    inner class VH(itemView: View)
        : RecyclerView.ViewHolder(itemView) {
        private var subRowPic = itemView.findViewById<ImageView>(R.id.subRowPic)
        private var subRowHeading = itemView.findViewById<TextView>(R.id.subRowHeading)
        private var subRowDetails = itemView.findViewById<TextView>(R.id.subRowDetails)
        init {
            itemView.setOnClickListener {
                viewModel.setSubreddit(subRowHeading.text.toString())
                viewModel.setTitleToSubreddit()
                viewModel.netRefresh()
                (itemView.context as FragmentActivity).supportFragmentManager.popBackStack()
            }
        }

        fun bind(post: RedditPost?) {
            if(post == null) {
                return
            }
            val url = post.iconURL ?: ""
            Glide.glideFetch(url, url, subRowPic)
            subRowHeading.text = post.displayName
            subRowDetails.text = post.publicDescription.toString()
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val itemView = LayoutInflater.from(parent.context)
            .inflate(R.layout.row_subreddit, parent, false)
        return VH(itemView)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        holder.bind(subreddits?.get(position))
    }

    override fun getItemCount(): Int {
        return subreddits?.size ?: 0
    }

}