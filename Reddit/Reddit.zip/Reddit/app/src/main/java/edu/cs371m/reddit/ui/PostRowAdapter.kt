package edu.cs371m.reddit.ui

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.core.app.ActivityCompat.startActivity
import androidx.core.app.ActivityCompat.startActivityForResult
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import edu.cs371m.reddit.OnePost
import edu.cs371m.reddit.R
import edu.cs371m.reddit.api.RedditPost
import edu.cs371m.reddit.glide.AppGlideModule
import edu.cs371m.reddit.glide.Glide
import kotlinx.android.synthetic.main.row_post.view.*

/**
 * Created by witchel on 8/25/2019
 */

// This adapter inherits from ListAdapter, which should mean that all we need
// to do is give it a new list and an old list and as clients we will never
// have to call notifyDatasetChanged().  Well, unfortunately, I can't implement
// equal for SpannableStrings correctly.  So clients of this adapter are, under
// certain circumstances, going to have to call notifyDatasetChanged()
class PostRowAdapter(private val viewModel: MainViewModel)
    : ListAdapter<RedditPost, PostRowAdapter.VH>(RedditDiff()) {
    class RedditDiff : DiffUtil.ItemCallback<RedditPost>() {

        override fun areItemsTheSame(oldItem: RedditPost, newItem: RedditPost): Boolean {
            return oldItem.key == newItem.key
        }

        override fun areContentsTheSame(oldItem: RedditPost, newItem: RedditPost): Boolean {
            return oldItem.title == newItem.title
                    && oldItem.selfText == newItem.selfText
                    && oldItem.publicDescription == newItem.publicDescription
                    && oldItem.displayName == oldItem.displayName
        }
    }
    inner class VH(v: View) : RecyclerView.ViewHolder(v) {
        //XXX
        private var selfTextTV = v.findViewById<TextView>(R.id.selfText)
        private var titleTV = v.findViewById<TextView>(R.id.title)
        private var imageIV = v.findViewById<ImageView>(R.id.image)
        private var scoreTV = v.findViewById<TextView>(R.id.score)
        private var commentsTV = v.findViewById<TextView>(R.id.comments)
        private var rowFav = v.findViewById<ImageView>(R.id.rowFav)

        init {
            titleTV.setOnClickListener {
                val onePostIntent = Intent(it.context, OnePost::class.java)
                val myExtras = Bundle()
                val post = viewModel.getListAt(adapterPosition)!!
                myExtras.putString("title", post.title.toString())
                myExtras.putString("image", post.imageURL)
                myExtras.putString("selfText", post.selfText.toString())
                myExtras.putString("thumbnail", post.thumbnailURL)
                onePostIntent.putExtras(myExtras)
                val result = 1
                startActivity(it.context, onePostIntent, myExtras)
            }
            rowFav.setOnClickListener {
                val position = adapterPosition
                // Toggle Favorite
                val local = viewModel.getListAt(position)
                local?.let {
                    if (viewModel.isFav(it)) {
                        viewModel.removeFav(it)
                    } else {
                        Log.d("XXX", "trying to adding to fav")
                        viewModel.addFav(it)
                    }
                    notifyItemChanged(position)
                }

            }
        }

        fun bind(post: RedditPost?){
            if(post == null) {
                return
            }
            selfTextTV.text = post.selfText
            titleTV.text = post.title
            Glide.glideFetch(post.imageURL,post.thumbnailURL,imageIV)
            scoreTV.text = post.score.toString()
            commentsTV.text = post.commentCount.toString()

            if (viewModel.isFav(post)) {
                Log.d("XXX", "binding fav")
                rowFav.setImageResource(R.drawable.ic_favorite_black_24dp)
            } else {
                rowFav.setImageResource(R.drawable.ic_favorite_border_black_24dp)
            }

        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        Log.d("here", "create view holder")

        val itemView = LayoutInflater.from(parent.context)
            .inflate(R.layout.row_post, parent, false)
        return VH(itemView)
    }
    override fun onBindViewHolder(holder: VH, position: Int) {
        Log.d("here", "trying to bind")
        holder.bind(getItem(holder.adapterPosition))
    }

}

